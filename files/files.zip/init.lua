require("core.lazy")
require("core.options")
require("core.keymaps")
require("core.treesitter")

require("ui")
