-- Neovim 0.12: treesitter highlighting is built-in.
-- nvim-treesitter (main branch) is only needed for parser installation.
-- Requires tree-sitter-cli: pacman -S tree-sitter

-- Parsers to auto-install (via nvim-treesitter plugin)
local ensure_installed = {
	"lua",
	"python",
	"typescript",
	"javascript",
	"rust",
	"go",
	"bash",
	"json",
	"yaml",
	"toml",
	"markdown",
	"markdown_inline",
	"html",
	"css",
	"c",
	"cpp",
}

-- Auto-install missing parsers on startup
local ok, ts = pcall(require, "nvim-treesitter")
if ok and ts.install then
	local installed = require("nvim-treesitter.config").get_installed()
	local to_install = vim.iter(ensure_installed)
		:filter(function(p)
			return not vim.tbl_contains(installed, p)
		end)
		:totable()
	if #to_install > 0 then
		ts.install(to_install)
	end
end

-- 0.12: Highlighting, indentation, and folding are native.
-- vim.treesitter.start() enables highlighting per-buffer.
-- Highlighting is on by default in 0.12 for bundled parsers.
vim.api.nvim_create_autocmd("FileType", {
	callback = function()
		-- Highlighting (native in 0.12)
		pcall(vim.treesitter.start)
		-- Folding (native)
		vim.wo[0][0].foldmethod = "expr"
		vim.wo[0][0].foldexpr = "v:lua.vim.treesitter.foldexpr()"
		vim.wo[0][0].foldlevel = 99 -- start unfolded
	end,
})

-- Folding hotkeys:
-- zo  → open fold under cursor
-- zO  → open fold recursively
-- zR  → open all folds in file
-- za  → toggle fold under cursor
-- zA  → toggle fold recursively
-- zc  → close fold under cursor
-- zC  → close fold recursively
-- zM  → close all folds in file
